import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.use('/api/*', (req, res) => {
    res.status(404).json({ message: 'API endpoint not found' });
  });

  // Handle client-side routing
  app.get('/*', (req, res, next) => {
    if (req.path.startsWith('/api/') || req.path.startsWith('/attached_assets/')) {
      next();
    } else {
      res.sendFile(path.join(process.cwd(), 'client', 'index.html'));
    }
  });

  // Serve attached assets
  app.get("/attached_assets/:filename", (req, res) => {
    const filePath = path.join(process.cwd(), "attached_assets", req.params.filename);
    
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).send("File not found");
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
