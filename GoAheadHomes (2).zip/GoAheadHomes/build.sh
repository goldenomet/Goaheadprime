
#!/bin/bash

# Run Vite build
npm run build

# Copy attached assets
cp -r attached_assets/* dist/public/attached_assets/

echo "Build completed successfully"
