import { useState } from "react";
import { Link } from "wouter";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openDropdowns, setOpenDropdowns] = useState<Record<string, boolean>>({});

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const toggleDropdown = (name: string) => {
    setOpenDropdowns((prev) => ({
      ...prev,
      [name]: !prev[name],
    }));
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center">
            <img 
              src="https://goaheadhomes.com/wp-content/uploads/2022/03/go-ahead-logo-1.png" 
              alt="Go Ahead Homes Logo" 
              className="h-16"
            />
          </Link>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={toggleMobileMenu} 
              className="text-neutral-dark focus:outline-none"
            >
              <span className={`ri-${mobileMenuOpen ? 'close' : 'menu'}-line text-2xl`}></span>
            </button>
          </div>
          
          {/* Desktop navigation */}
          <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
            <Link href="/" className="hover:text-primary uppercase">HOME</Link>
            <Link href="#" className="hover:text-primary uppercase">ABOUT US</Link>
            
            {/* Dropdown menu - Services */}
            <div className="relative group">
              <button className="flex items-center hover:text-primary uppercase">
                OUR SERVICES
                <span className="ri-arrow-down-s-line ml-1"></span>
              </button>
              <div className="absolute z-10 hidden group-hover:block bg-white shadow-lg py-2 w-48 mt-1">
                <Link href="#" className="block px-4 py-2 hover:bg-neutral-light">Semi-Independent Living</Link>
                <Link href="#" className="block px-4 py-2 hover:bg-neutral-light">Support Services</Link>
                <Link href="#" className="block px-4 py-2 hover:bg-neutral-light">Education & Training</Link>
              </div>
            </div>
            
            {/* Dropdown menu - Referrals */}
            <div className="relative group">
              <button className="flex items-center hover:text-primary uppercase">
                REFERRALS
                <span className="ri-arrow-down-s-line ml-1"></span>
              </button>
              <div className="absolute z-10 hidden group-hover:block bg-white shadow-lg py-2 w-48 mt-1">
                <Link href="#" className="block px-4 py-2 hover:bg-neutral-light">Referral Process</Link>
                <Link href="#" className="block px-4 py-2 hover:bg-neutral-light">Placement Request</Link>
              </div>
            </div>
            
            {/* Dropdown menu - Success Stories */}
            <div className="relative group">
              <button className="flex items-center hover:text-primary uppercase">
                SUCCESS STORIES
                <span className="ri-arrow-down-s-line ml-1"></span>
              </button>
              <div className="absolute z-10 hidden group-hover:block bg-white shadow-lg py-2 w-48 mt-1">
                <Link href="#" className="block px-4 py-2 hover:bg-neutral-light">Case Studies</Link>
                <Link href="#" className="block px-4 py-2 hover:bg-neutral-light">Testimonials</Link>
              </div>
            </div>
            
            <Link href="#" className="hover:text-primary uppercase">BLOG</Link>
            <Link href="#" className="hover:text-primary uppercase">RECRUITMENT</Link>
            <Link href="#" className="hover:text-primary uppercase">CONTACT US</Link>
          </nav>
        </div>
      </div>
      
      {/* Mobile navigation */}
      <nav className={`px-4 py-3 bg-white md:hidden ${mobileMenuOpen ? '' : 'hidden'}`}>
        <Link href="/" className="block py-2 hover:text-primary">HOME</Link>
        <Link href="#" className="block py-2 hover:text-primary">ABOUT US</Link>
        
        {/* Mobile dropdown - Services */}
        <div className="mobile-dropdown">
          <button 
            onClick={() => toggleDropdown('services')} 
            className="flex justify-between w-full py-2 hover:text-primary"
          >
            OUR SERVICES
            <span className={`ri-arrow-${openDropdowns['services'] ? 'up' : 'down'}-s-line`}></span>
          </button>
          <div className={openDropdowns['services'] ? 'pl-4' : 'hidden pl-4'}>
            <Link href="#" className="block py-2 hover:text-primary">Semi-Independent Living</Link>
            <Link href="#" className="block py-2 hover:text-primary">Support Services</Link>
            <Link href="#" className="block py-2 hover:text-primary">Education & Training</Link>
          </div>
        </div>
        
        {/* Mobile dropdown - Referrals */}
        <div className="mobile-dropdown">
          <button 
            onClick={() => toggleDropdown('referrals')} 
            className="flex justify-between w-full py-2 hover:text-primary"
          >
            REFERRALS
            <span className={`ri-arrow-${openDropdowns['referrals'] ? 'up' : 'down'}-s-line`}></span>
          </button>
          <div className={openDropdowns['referrals'] ? 'pl-4' : 'hidden pl-4'}>
            <Link href="#" className="block py-2 hover:text-primary">Referral Process</Link>
            <Link href="#" className="block py-2 hover:text-primary">Placement Request</Link>
          </div>
        </div>
        
        {/* Mobile dropdown - Success Stories */}
        <div className="mobile-dropdown">
          <button 
            onClick={() => toggleDropdown('success')} 
            className="flex justify-between w-full py-2 hover:text-primary"
          >
            SUCCESS STORIES
            <span className={`ri-arrow-${openDropdowns['success'] ? 'up' : 'down'}-s-line`}></span>
          </button>
          <div className={openDropdowns['success'] ? 'pl-4' : 'hidden pl-4'}>
            <Link href="#" className="block py-2 hover:text-primary">Case Studies</Link>
            <Link href="#" className="block py-2 hover:text-primary">Testimonials</Link>
          </div>
        </div>
        
        <Link href="#" className="block py-2 hover:text-primary">BLOG</Link>
        <Link href="#" className="block py-2 hover:text-primary">RECRUITMENT</Link>
        <Link href="#" className="block py-2 hover:text-primary">CONTACT US</Link>
      </nav>
    </header>
  );
};

export default Header;
