import { Link } from "wouter";
import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

const slides = [
  {
    id: 1,
    image: "/attached_assets/GAH-Brand_20250418_162413_13.png",
    title: "GIVING HOPE TO YOUNG PEOPLE",
    subtitle: "GO AHEAD HOMES",
    description: "We are an Ofsted-registered independent support provider specialising in semi-independent accommodation for 16+ care leavers across the UK.",
    cta: "Place with us",
    icon: "ri-bar-chart-line"
  },
  {
    id: 2,
    image: "/attached_assets/GAH.png",
    title: "INDIVIDUAL-CENTRED SUPPORT",
    subtitle: "GO AHEAD HOMES",
    description: "We provide a tailored service which targets the specific needs of each young person.",
    cta: "Work with us",
    icon: "ri-user-heart-line"
  },
  {
    id: 3,
    image: "/attached_assets/GAH-Brand_20250418_162413_8.png",
    title: "A HOMELY ENVIRONMENT",
    subtitle: "GO AHEAD HOMES",
    description: "We go the extra mile to make our homes warm, nurturing and well-suited for our residents.",
    cta: "Find out more",
    icon: "ri-home-heart-line"
  }
];

const HeroBanner = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const resetTimeout = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
  };

  useEffect(() => {
    resetTimeout();
    timeoutRef.current = setTimeout(() => {
      setCurrentIndex((prevIndex) => (prevIndex === slides.length - 1 ? 0 : prevIndex + 1));
    }, 6000);

    return () => {
      resetTimeout();
    };
  }, [currentIndex]);

  const goToSlide = (index: number) => {
    resetTimeout();
    setCurrentIndex(index);
  };

  const currentSlide = slides[currentIndex];

  return (
    <section className="relative h-[600px] overflow-hidden">
      {/* Slide background with parallax effect */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          className="absolute inset-0"
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.2, ease: "easeInOut" }}
        >
          <div className="absolute inset-0 w-full h-full">
            <img 
              src={currentSlide.image} 
              alt={currentSlide.title} 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/40"></div>
          </div>
        </motion.div>
      </AnimatePresence>
      
      {/* Dot indicator navigation */}
      <div className="absolute top-1/2 left-6 transform -translate-y-1/2 z-30 flex flex-col gap-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            aria-label={`Go to slide ${index + 1}`}
            className="w-3 h-3 rounded-full transition-all duration-300 focus:outline-none"
          >
            <span 
              className={`block w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentIndex 
                  ? "bg-white scale-125" 
                  : "bg-white/50 hover:bg-white/70"
              }`}
            />
          </button>
        ))}
      </div>
      
      {/* Content */}
      <div className="container mx-auto px-6 md:px-10 relative z-10 h-full flex items-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            className="max-w-2xl text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ 
              duration: 0.8, 
              ease: "easeOut",
              staggerChildren: 0.1
            }}
          >
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: "4rem" }}
              transition={{ duration: 0.8, ease: "easeInOut", delay: 0.2 }}
              className="h-px bg-white mb-4"
            />
            
            <motion.p 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-lg uppercase tracking-wide mb-2 font-montserrat"
            >
              {currentSlide.subtitle}
            </motion.p>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-4xl md:text-5xl font-bold font-montserrat leading-tight mb-6"
            >
              {currentSlide.title}
            </motion.h1>
            
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="pl-6 border-l-2 border-white mb-8"
            >
              <p className="text-xl">{currentSlide.description}</p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              <Link 
                href="#" 
                className="inline-flex items-center bg-white text-accent px-6 py-3 rounded-sm font-semibold transition-all hover:bg-primary hover:text-white hover:shadow-lg"
              >
                <span className={`${currentSlide.icon} mr-2`}></span>
                {currentSlide.cta.toUpperCase()}
              </Link>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
};

export default HeroBanner;
