import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-white pt-12 pb-6 border-t">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center mb-10">
          <div className="mb-6 md:mb-0">
            <Link href="/">
              <img 
                src="https://goaheadhomes.com/wp-content/uploads/2022/03/go-ahead-logo-1.png" 
                alt="Go Ahead Homes Logo" 
                className="h-16" 
              />
            </Link>
          </div>
          
          <div className="flex flex-col md:flex-row gap-8">
            <div>
              <h3 className="font-montserrat font-semibold mb-3">Contact</h3>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <span className="ri-mail-line mr-2 text-primary"></span>
                  <a href="mailto:info@goaheadhomes.com" className="hover:text-primary">info@goaheadhomes.com</a>
                </li>
                <li className="flex items-center">
                  <span className="ri-map-pin-line mr-2 text-primary"></span>
                  <span>East London, UK</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-montserrat font-semibold mb-3">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link href="#" className="hover:text-primary">About Us</Link></li>
                <li><Link href="#" className="hover:text-primary">Our Services</Link></li>
                <li><Link href="#" className="hover:text-primary">Referrals</Link></li>
                <li><Link href="#" className="hover:text-primary">Contact Us</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-montserrat font-semibold mb-3">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-neutral-dark hover:text-primary text-xl"><span className="ri-facebook-fill"></span></a>
                <a href="#" className="text-neutral-dark hover:text-primary text-xl"><span className="ri-twitter-fill"></span></a>
                <a href="#" className="text-neutral-dark hover:text-primary text-xl"><span className="ri-linkedin-fill"></span></a>
                <a href="#" className="text-neutral-dark hover:text-primary text-xl"><span className="ri-instagram-line"></span></a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t pt-6">
          <p className="text-center text-sm">Copyright © 2023. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
