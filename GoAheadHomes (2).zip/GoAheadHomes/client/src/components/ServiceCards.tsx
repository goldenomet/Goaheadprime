import { Link } from "wouter";

const ServiceCards = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-gray-50 rounded-lg shadow-md p-6 transition-all hover:shadow-lg">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Oversight</h3>
            <p className="text-gray-600 mb-4">Our accommodation is managed by experienced staff who provide appropriate oversight and guidance.</p>
            <Link href="#" className="text-primary font-medium hover:underline">Learn more</Link>
          </div>
          
          <div className="bg-gray-50 rounded-lg shadow-md p-6 transition-all hover:shadow-lg">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Personalized Support</h3>
            <p className="text-gray-600 mb-4">We develop individual support plans tailored to meet each young person's specific needs.</p>
            <Link href="#" className="text-primary font-medium hover:underline">Learn more</Link>
          </div>
          
          <div className="bg-gray-50 rounded-lg shadow-md p-6 transition-all hover:shadow-lg">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 24 24">
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Quality Accommodation</h3>
            <p className="text-gray-600 mb-4">Our homes are designed to provide a safe, comfortable and supportive environment.</p>
            <Link href="#" className="text-primary font-medium hover:underline">Learn more</Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServiceCards;
