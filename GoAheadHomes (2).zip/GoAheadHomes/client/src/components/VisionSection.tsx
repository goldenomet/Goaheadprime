import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const VisionSection = () => {
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (email) {
      // In a real implementation, this would submit to a server
      toast({
        title: "Thank you for subscribing!",
        description: "You'll receive our updates soon.",
      });
      setEmail("");
    }
  };

  return (
    <section className="py-16 bg-neutral-light">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          {/* Image Section */}
          <div className="md:w-1/2 mb-10 md:mb-0 md:pr-10">
            <img 
              src="https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&q=80" 
              alt="Young people in supportive community" 
              className="rounded-lg shadow-md w-full h-auto object-cover"
            />
          </div>
          
          {/* Vision Content */}
          <div className="md:w-1/2">
            <div className="bg-white rounded-lg shadow-md p-8">
              <h2 className="text-3xl font-montserrat font-bold text-primary mb-6">OUR VISION</h2>
              <p className="text-lg mb-8">
                We envision a society in which all young people from disadvantaged backgrounds are empowered to overcome their challenges and strive towards a bright and successful future.
              </p>
              
              {/* Email Sign Up */}
              <div>
                <h3 className="text-xl font-semibold mb-4">Sign up for emails</h3>
                <form className="flex flex-col sm:flex-row gap-3" onSubmit={handleSubmit}>
                  <input 
                    type="email" 
                    placeholder="Your email address" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="flex-grow px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary" 
                    required
                  />
                  <button 
                    type="submit" 
                    className="bg-primary text-white px-6 py-2 rounded-md font-semibold hover:bg-accent transition"
                  >
                    Subscribe
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VisionSection;
